# MyLight150 Dashboard - Android APK

App Android native complete pour MyLight150.

## Build APK

### Methode rapide (Android Studio)
1. Ouvre ce dossier dans Android Studio Hedgehog+
2. Attends sync Gradle
3. Menu Build > Build APK(s) > Build APK
4. APK dans app/build/outputs/apk/debug/app-debug.apk
5. Copie sur ton tel et installe

### Ligne de commande
```bash
./gradlew assembleDebug
# ou
gradlew.bat assembleDebug (Windows)
```

### Build cloud gratuit (sans installer Android Studio)
1. Cree un repo GitHub, pousse ce code
2. Va dans Actions > New workflow > colle ce YAML:

```yaml
name: Build APK
on: [push]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with: { java-version: '17', distribution: 'temurin' }
      - run: chmod +x gradlew
      - run: ./gradlew assembleDebug
      - uses: actions/upload-artifact@v4
        with: { name: mylight150-apk, path: app/build/outputs/apk/debug/app-debug.apk }
```
3. Push -> 3 min apres ton APK est pret en artefact telechargeable

## Connexion
Utilise exactement tes identifiants app.mylight150.com (email + mot de passe).
L'app essaie automatiquement 3 base URLs: app.mylight150.com, myapi.mylight150.com, api.mylight150.com

## Mock
Si login echoue, l'app affiche des donnees mock pour tester le design.

## Prochaines evolutions
- Graphique MPAndroidChart / Compose Charts
- Notifications si batterie vide
- Widget Android
- Export CSV

## Securite
Aucune donnee envoyee ailleurs que MyLight150. Token en memoire seulement.
