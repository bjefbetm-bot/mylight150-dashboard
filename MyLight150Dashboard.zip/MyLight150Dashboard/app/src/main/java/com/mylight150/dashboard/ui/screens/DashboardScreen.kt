package com.mylight150.dashboard.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mylight150.dashboard.data.DashboardData
import com.mylight150.dashboard.data.MyLightRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardApp(){
    var loggedIn by remember { mutableStateOf(false) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var data by remember { mutableStateOf<DashboardData?>(null) }
    val repo = remember { MyLightRepository() }
    val scope = rememberCoroutineScope()
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    if(!loggedIn){
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center){
            Text("MyLight150 Dashboard", style = MaterialTheme.typography.headlineLarge, color = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text("Connecte-toi avec tes identifiants mylight150.com", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(value=email, onValueChange={email=it}, label={Text("Email MyLight150")}, modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(value=password, onValueChange={password=it}, label={Text("Mot de passe")}, modifier=Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            if(error!=null) { Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.errorContainer)){ Text(error!!, modifier=Modifier.padding(12.dp)) }; Spacer(Modifier.height(8.dp)) }
            Button(onClick={
                loading=true; error=null
                scope.launch{
                    try{ repo.login(email.trim(),password.trim()); data=repo.getDashboard(); loggedIn=true }
                    catch(e: Exception){ error=e.message ?: "Erreur inconnue" } finally{ loading=false }
                }
            }, modifier=Modifier.fillMaxWidth().height(50.dp), enabled=!loading){ Text(if(loading)"Connexion..." else "Se connecter") }
            Spacer(Modifier.height(12.dp))
            Text("Securite: identifiants stockes uniquement sur ton telephone, appel direct API MyLight150. Aucun serveur tiers.", style=MaterialTheme.typography.bodySmall)
        }
    } else {
        LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)){
            item{ 
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween){ Text("Dashboard", style=MaterialTheme.typography.headlineMedium); TextButton(onClick={loggedIn=false}){ Text("Deconnexion") } }
            }
            item{
                val d=data
                if(d==null) CircularProgressIndicator()
                else {
                    Column(verticalArrangement=Arrangement.spacedBy(12.dp)){
                        Card(shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.primaryContainer)){ Column(Modifier.padding(16.dp)){ Text("Production solaire actuelle"); Text("${d.solarProduction} kW", style=MaterialTheme.typography.headlineLarge) } }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)){
                            Card(Modifier.weight(1f), shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(12.dp)){ Text("Conso maison"); Text("${d.load} kW", style=MaterialTheme.typography.titleLarge) } }
                            Card(Modifier.weight(1f), shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(12.dp)){ Text("Reseau"); Text("${d.grid} kW", style=MaterialTheme.typography.titleLarge) } }
                        }
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(12.dp)){
                            Card(Modifier.weight(1f), shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.secondaryContainer)){ Column(Modifier.padding(12.dp)){ Text("Injection"); Text("${d.injection} kW") } }
                            Card(Modifier.weight(1f), shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(12.dp)){ Text("Batterie P"); Text("${d.msbPower} kW") } }
                        }
                        Card(shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(16.dp)){
                            Text("Batterie virtuelle - ${d.msbState}", style=MaterialTheme.typography.titleMedium)
                            LinearProgressIndicator(progress={ (d.msbAutonomy/d.msbCapacity).toFloat().coerceIn(0f,1f) }, modifier=Modifier.fillMaxWidth().padding(top=8.dp))
                            Spacer(Modifier.height(8.dp))
                            Text("${d.msbAutonomy} / ${d.msbCapacity} kWh")
                            Text("${((d.msbAutonomy/d.msbCapacity)*100).toInt()}% d'autonomie")
                        }}
                        Card(shape=RoundedCornerShape(20.dp), colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.tertiaryContainer)){ Column(Modifier.padding(16.dp)){ Text("Cagnotte"); Text("${d.moneyPot} €", style=MaterialTheme.typography.headlineSmall) } }
                        Card(shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(16.dp)){
                            Text("Energie totale", style=MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text("Production solaire: ${d.energyProdFromSolar} kWh")
                            Text("Consommation: ${d.energyConsumption} kWh")
                            Text("Vers batterie: ${d.energyProdToMsb} kWh")
                            Text("Vers reseau: ${d.energyProdToGrid} kWh")
                        }}
                        Card(shape=RoundedCornerShape(20.dp)){ Column(Modifier.padding(16.dp)){
                            Text("Historique aujourd'hui", style=MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            d.history.forEach{ h -> Text("${h.time}: prod ${h.solar}kW / conso ${h.load}kW / inj ${h.injection}kW", style=MaterialTheme.typography.bodySmall) }
                        }}
                        Button(onClick={ scope.launch{ data=repo.getDashboard() } }, modifier=Modifier.fillMaxWidth()){ Text("Rafraichir maintenant") }
                        OutlinedButton(onClick={ loggedIn=false }, modifier=Modifier.fillMaxWidth()){ Text("Changer de compte") }
                    }
                }
            }
        }
    }
}
