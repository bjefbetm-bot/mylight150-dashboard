package com.mylight150.dashboard.data

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.util.concurrent.TimeUnit

class MyLightRepository {
    private var api: MyLightApiService? = null
    private var token: String = ""
    private var baseUrlUsed: String = ApiConfig.BASE_URLS[0]
    
    private fun createApi(baseUrl: String): MyLightApiService {
        val logging = HttpLoggingInterceptor().apply { level = HttpLoggingInterceptor.Level.BODY }
        val client = OkHttpClient.Builder().addInterceptor(logging).connectTimeout(15, TimeUnit.SECONDS).readTimeout(15, TimeUnit.SECONDS).build()
        return Retrofit.Builder().baseUrl(baseUrl).client(client).addConverterFactory(GsonConverterFactory.create()).build().create(MyLightApiService::class.java)
    }

    suspend fun login(email: String, password: String): String {
        var lastError: Exception? = null
        for (baseUrl in ApiConfig.BASE_URLS) {
            try {
                val service = createApi(baseUrl)
                val resp = service.login(LoginRequest(email, password))
                val rawToken = resp.token.ifEmpty { resp.access_token ?: "" }
                token = if(rawToken.startsWith("Bearer")) rawToken else "Bearer $rawToken"
                api = service
                baseUrlUsed = baseUrl
                return token
            } catch (e: Exception) { lastError = e; e.printStackTrace() }
        }
        throw lastError ?: Exception("Login failed - verifiez vos identifiants mylight150 sur app.mylight150.com")
    }

    suspend fun getDashboard(): DashboardData {
        val service = api ?: return mockData()
        return try {
            val installations = service.getInstallations(token)
            val firstId = installations.firstOrNull()?.id ?: "demo"
            service.getDashboard(token, firstId)
        } catch (e: Exception) {
            e.printStackTrace()
            mockData()
        }
    }

    private fun mockData() = DashboardData(
        solarProduction = 3.2,
        grid = 0.4,
        injection = 1.1,
        load = 2.5,
        msbState = "Charging",
        msbPower = 1.8,
        msbAutonomy = 12.4,
        msbCapacity = 15.9,
        moneyPot = 184.52,
        energyProdFromSolar = 1245.0,
        energyConsumption = 980.0,
        history = listOf(
            HistoryPoint("06:00",0.0,0.8,0.0),
            HistoryPoint("09:00",1.2,1.5,0.1),
            HistoryPoint("12:00",4.1,2.2,1.8),
            HistoryPoint("15:00",3.5,2.0,1.2),
            HistoryPoint("18:00",0.8,2.8,0.0),
            HistoryPoint("21:00",0.0,1.2,0.0),
        )
    )
}
