package com.mylight150.dashboard.data

import retrofit2.http.*

data class LoginRequest(val email: String, val password: String)
data class LoginResponse(val token: String, val refreshToken: String? = null, val userId: String? = null, val access_token: String? = null)

data class Installation(val id: String, val code: String, val name: String)

data class DashboardData(
    val solarProduction: Double,
    val grid: Double,
    val injection: Double,
    val load: Double,
    val msbState: String,
    val msbPower: Double,
    val msbAutonomy: Double,
    val msbCapacity: Double,
    val moneyPot: Double,
    val energyProdFromSolar: Double = 0.0,
    val energyProdToMsb: Double = 0.0,
    val energyProdToGrid: Double = 0.0,
    val energyConsumption: Double = 0.0,
    val energyConsoFromSolar: Double = 0.0,
    val energyConsoFromMsb: Double = 0.0,
    val energyConsoFromGrid: Double = 0.0,
    val history: List<HistoryPoint> = emptyList()
)

data class HistoryPoint(val time: String, val solar: Double, val load: Double, val injection: Double)

interface MyLightApiService {
    @POST("api/auth/login")
    suspend fun login(@Body req: LoginRequest): LoginResponse

    @GET("api/installations")
    suspend fun getInstallations(@Header("Authorization") token: String): List<Installation>

    @GET("api/installations/{id}/dashboard")
    suspend fun getDashboard(@Header("Authorization") token: String, @Path("id") installationId: String): DashboardData
}

object ApiConfig {
    val BASE_URLS = listOf(
        "https://app.mylight150.com/",
        "https://myapi.mylight150.com/",
        "https://api.mylight150.com/"
    )
}
