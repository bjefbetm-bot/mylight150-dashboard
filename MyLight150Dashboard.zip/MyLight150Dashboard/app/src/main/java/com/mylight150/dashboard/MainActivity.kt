package com.mylight150.dashboard
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.mylight150.dashboard.ui.theme.MyLightTheme
import com.mylight150.dashboard.ui.screens.DashboardApp
class MainActivity: ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?){ super.onCreate(savedInstanceState); setContent{ MyLightTheme{ DashboardApp() } } }
}
